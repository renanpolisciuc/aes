import os
import sys


print "[LOG] Gerando graficos...",
i = 1
 #while i < 9:
	#os.system ("gnuplot "+str(i)+".gnu")
	#i = i + 1
os.system ("gnuplot 8.gnu")
print "done."
