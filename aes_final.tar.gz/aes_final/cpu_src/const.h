//Número de rodadas do AES 128 bits
#define R_ROUNDS 10

//Número de chaves do AES. 176 = 16 * 11 (1 para cada rodada do AES + chave escolhida pelo usuário)
#define EXP_KEY_SIZE 176
