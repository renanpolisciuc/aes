extern unsigned char S_BOX[256];
extern unsigned char mul2[];
extern unsigned char mul3[];
extern unsigned char rcon[11];
